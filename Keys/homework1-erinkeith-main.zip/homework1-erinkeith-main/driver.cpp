#include <iostream>
using namespace std;

#include "train.h"
#include "cargo.h"
#include "bus.h"
#include "person.h"

int main(){
    Train<Cargo> newTrain;
    Cargo stuff("potatoes", 3.3);

    newTrain.load(stuff);
    newTrain.load(stuff);
    cout << newTrain.calcWeight() << endl;

    newTrain.unload(stuff);
    cout << newTrain.calcWeight() << endl;

    newTrain.empty();
    cout << newTrain.calcWeight() << endl;

    newTrain.move();
    
    Bus<Person> newBus;
    Person me("Erin", 68);
    Person them("Riley", 66);
    Person someoneElse("River", 70);

    newBus.load(me);
    newBus.load(them);
    newBus.load(someoneElse);
    newBus.unload(someoneElse);

    newBus.empty();
    newBus.move();
    
    return 0;
}