#ifndef BUS_H
#define BUS_H

#include "transporter.h"

template<class ItemType>
class Bus: public TransporterInterface<ItemType>{
private:
    static const int DEFAULT_CAPACITY = 100;
    int itemCount;
    float fare;
    ItemType items[DEFAULT_CAPACITY - 1];
public:
    Bus();

    bool isEmpty() const;
    int getNumberItems() const;
    bool load(const ItemType&);
    bool unload(const ItemType&);
    void empty();
    void move();

    float getTotalFare() const;
    void setFare(float);

    ~Bus() {}
};
#include "bus.cpp"
#endif
