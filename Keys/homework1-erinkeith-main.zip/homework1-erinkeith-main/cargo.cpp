#include "cargo.h"
    
Cargo::Cargo(){
    weight = 0.0;
}
Cargo::Cargo(string newType, float newWeight){
    type = newType;
    weight = newWeight;
}
Cargo::Cargo(const Cargo& rhs){
    type = rhs.type;
    weight = rhs.weight;
}

void Cargo::setType(string newType){
    type = newType;
}
void Cargo::setWeight(float newWeight){
    weight = newWeight;
}

string Cargo::getType() const{
    return type;
}
float Cargo::getWeight() const{
    return weight;
}

float Cargo::operator+(float rhs){
    return this->weight + rhs;
}

bool Cargo::operator==(const Cargo& rhs){
    return this->weight == rhs.weight && this->type == rhs.type;
}
