#include "train.h"

#include <iostream>
using namespace std;

template<class ItemType> 
Train<ItemType>::Train(){
    itemCount = 0;
    latitude = 0.0;
    longitude = 0.0;
}

template<class ItemType> 
bool Train<ItemType>::isEmpty() const{
    return itemCount == 0;
}

template<class ItemType> 
int Train<ItemType>::getNumberItems() const{
    return itemCount;
}

template<class ItemType> 
bool Train<ItemType>::load(const ItemType& newItem){
    bool canLoad = itemCount < DEFAULT_CAPACITY;

    if (canLoad){
        items[itemCount] = newItem;
        itemCount++;
    } 

    return canLoad;
}

template<class ItemType> 
bool Train<ItemType>::unload(const ItemType& removeItem){
    bool canRemove = false;
    int index = 0;

    while(index < itemCount && !canRemove){
        if(items[index] == removeItem){
            canRemove = true;
        }
        else{
            index++;
        }
    }

    if(canRemove){
        for(int i = index; i < itemCount; i++){
            items[i] = items[i + 1];
        }
        itemCount--;
    }

    return canRemove;
}

template<class ItemType> 
void Train<ItemType>::empty(){
    itemCount = 0;
}

template<class ItemType> 
void Train<ItemType>::move(){
    cout << "Train has reached next destination" << endl;
}

template<class ItemType> 
float Train<ItemType>::calcWeight(){
    float sum = 0.0;

    for(int index = 0; index < itemCount; index++){
        sum = items[index] + sum;
    }

    return sum;
}