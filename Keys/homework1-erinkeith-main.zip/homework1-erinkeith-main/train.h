#ifndef TRAIN_H
#define TRAIN_H

#include "transporter.h"

template<class ItemType>
class Train: public TransporterInterface<ItemType>{
private:
    static const int DEFAULT_CAPACITY = 100;
    int itemCount;
    float latitude, longitude;
    ItemType items[DEFAULT_CAPACITY - 1];
public:
    Train();

    bool isEmpty() const;
    int getNumberItems() const;
    bool load(const ItemType&);
    bool unload(const ItemType&);
    void empty();
    void move();

    float calcWeight();

    ~Train() {}
};
#include "train.cpp"
#endif
