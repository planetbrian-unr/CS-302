#include "bus.h"

#include <iostream>
using namespace std;

template<class ItemType> 
Bus<ItemType>::Bus(){
    itemCount = 0;
    fare = 0.0;
}

template<class ItemType> 
bool Bus<ItemType>::isEmpty() const{
    return itemCount == 0;
}

template<class ItemType> 
int Bus<ItemType>::getNumberItems() const{
    return itemCount;
}

template<class ItemType> 
bool Bus<ItemType>::load(const ItemType& newItem){
    bool canLoad = itemCount < DEFAULT_CAPACITY;
    int current = 0;

    if (canLoad){
        while(items[current] < newItem  && current < itemCount){
            current++;
        }
    } 
    for(int i = itemCount; i > current; i--){
        items[i] = items[i - 1];
    }
    items[current] = newItem;
    itemCount++;

    return canLoad;
}

template<class ItemType> 
bool Bus<ItemType>::unload(const ItemType& removeItem){
    bool canRemove = false;
    int index = 0;

    while(index < itemCount && !canRemove){
        if(items[index] == removeItem){
            canRemove = true;
        }
        else{
            index++;
        }
    }

    if(canRemove){
        for(int i = index; i < itemCount; i++){
            items[i] = items[i + 1];
        }
        itemCount--;
    }

    return canRemove;
}

template<class ItemType> 
void Bus<ItemType>::empty(){
    itemCount = 0;
}

template<class ItemType> 
void Bus<ItemType>::move(){
    cout << "Bus has reached next stop" << endl;
}

template<class ItemType> 
float Bus<ItemType>::getTotalFare() const{
    return fare * itemCount;
}

template<class ItemType> 
void Bus<ItemType>::setFare(float newFare){
    fare = newFare;
}
