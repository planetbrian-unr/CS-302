#include "person.h"
    
Person::Person(){
    heightInInches = 0.0;
}
Person::Person(string newName, int newHeight){
    name = newName;
    heightInInches = newHeight;
}
Person::Person(const Person& rhs){
    name = rhs.name;
    heightInInches = rhs.heightInInches;
}

void Person::setName(string newName){
    name = newName;
}
void Person::setHeight(int newHeight){
    heightInInches = newHeight;
}

string Person::getName() const{
    return name;
}
int Person::getHeight() const{
    return heightInInches;
}

bool Person::operator<(const Person& rhs){
    return this->heightInInches < rhs.heightInInches;
}

bool Person::operator==(const Person& rhs){
    return this->heightInInches == rhs.heightInInches && this->name == rhs.name;
}
