
#include <string>
#include <iostream>
#include <list>
using namespace std;

#include "amgraph.h"

void displayPath(list<string>&);
void addCityToPath(string&);

list<string> path;

int main(){
    AMGraph<string> cityGraph;

    cityGraph.add("Reno", "San Fransisco", 229);
    cityGraph.add("San Fransisco", "Seattle", 808);
    cityGraph.add("Seattle", "Salt Lake City", 830);
    cityGraph.add("Reno", "Las Vegas", 439);
    cityGraph.add("Reno", "Salt Lake City", 518);

    cout << "Vertices: " << cityGraph.getNumVertices() << " Edges: " << cityGraph.getNumEdges() << endl;

    cityGraph.breadthFirstTraversal("Reno", addCityToPath);
    cout << "breadth" << endl;
    displayPath(path);

    path.clear();
    cityGraph.depthFirstTraversal("Reno", addCityToPath);
    cout << "depth" << endl;
    displayPath(path);

    cityGraph.remove("Reno", "Las Vegas");
    cout << endl << "Vertices: " << cityGraph.getNumVertices() << " Edges: " << cityGraph.getNumEdges() << endl;

    path.clear();
    cityGraph.breadthFirstTraversal("Reno", addCityToPath);
    cout << "breadth" << endl;
    displayPath(path);

    path.clear();
    cityGraph.depthFirstTraversal("Reno", addCityToPath);
    cout << "depth" << endl;
    displayPath(path);

    return 0;
}

void displayPath(list<string>& thisPath){
    list<string>::iterator it;
    int index;

    for (it = thisPath.begin(), index = 0; index < thisPath.size() - 1; ++it, index++){
        cout << *it << ", ";
    }

    cout << *it << endl;
}
void addCityToPath(string& city){
    path.push_back(city);
}