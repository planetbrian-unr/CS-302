#include "amgraph.h"
#include <stack>
#include <queue>

#define CAN_ADD numItems < DEFAULT_CAPACITY

template<class LabelType>
AMGraph<LabelType>::AMGraph(){
    numItems = 0;
    numWeights = 0;

    for(int rowIndex = 0; rowIndex < DEFAULT_CAPACITY; rowIndex++){
        for(int colIndex = 0; colIndex < DEFAULT_CAPACITY; colIndex++){
            weights[rowIndex][colIndex] = __INT_MAX__;
        }
    }
}

template<class LabelType>
int AMGraph<LabelType>::getVertexIndex(const LabelType item) const{
    bool found = false;
    int ind;

    for(ind = 0; ind < numItems && !found; ind++){
        if(item == items[ind]){
            found = true;
        }
    }
    if(found){
        return ind - 1;
    }
    else{
        throw "item not found";
    }
}

template<class LabelType>
void AMGraph<LabelType>::removeVertex(int removeIndex){
    // shift row weights up
    for(int ind = removeIndex; ind < numItems - 1; ind++){
        for(int del = 0; del < numItems; del++){
            weights[ind][del] = weights[ind + 1][del];
        }
    }
    // shift column weights left
    for(int del = 0; del < numItems - 1; del++){
        for(int ind = removeIndex; ind < numItems - 1; ind++){
            weights[del][ind] = weights[del][ind + 1];
        }
    }
    // shift vertices (up)
    for(int ind = removeIndex; ind < numItems - 1; ind++){
        items[ind] = items[ind + 1];
    }
    numItems--;
}

template<class LabelType>
bool AMGraph<LabelType>::isVertexConnected(int vertexIndex) const{
    for(int index = 0; index < numItems; index++){
        if(weights[vertexIndex][index] != __INT_MAX__){
            return true;
        }
    }
    return false;
}


template<class LabelType>
int AMGraph<LabelType>::getNumVertices() const{
    return numItems;
}
    
template<class LabelType>
int AMGraph<LabelType>::getNumEdges() const{
    return numWeights;
}
    
template<class LabelType>
bool AMGraph<LabelType>::add(LabelType start, LabelType end, int edgeWeight){
    bool firstAdded = false;
    
    int firstIndex;    
    try{
        firstIndex = getVertexIndex(start);
    }
    catch(const char* e){
        if(CAN_ADD){
            items[numItems] = start;
            firstIndex = numItems;
            numItems++;
            firstAdded = true;
        }
        else{
            return false;
        }
    }
    
    int secondIndex;
    try{
        secondIndex = getVertexIndex(end);
    }
    catch(const char* e){
        if(CAN_ADD){
            items[numItems] = end;
            secondIndex = numItems;
            numItems++;
        }
        else{
            if(firstAdded){
                numItems--;
            }
            return false;
        }   
    }

    weights[firstIndex][secondIndex] = edgeWeight;
    weights[secondIndex][firstIndex] = edgeWeight;
    numWeights++;
    
    return true;
}
    
template<class LabelType>
bool AMGraph<LabelType>::remove(LabelType start, LabelType end){
    int firstIndex;
    try{
        firstIndex = getVertexIndex(start);
    }
    catch(const char* e){
        return false;
    }

    int secondIndex;
    try{
        secondIndex = getVertexIndex(end);
    }
    catch(const char* e){
        return false;
    }

    if(weights[firstIndex][secondIndex] == __INT_MAX__ && weights[secondIndex][firstIndex] == __INT_MAX__){
        return false;
    }
    
    weights[firstIndex][secondIndex] = __INT_MAX__;
    weights[secondIndex][firstIndex] = __INT_MAX__;
    numWeights--;

    if(!isVertexConnected(firstIndex)){
        removeVertex(firstIndex);
    }
    if(!isVertexConnected(secondIndex)){
        removeVertex(secondIndex);
    }
    return true;
}

template<class LabelType>
int AMGraph<LabelType>::getEdgeWeight(LabelType start, LabelType end) const{
    int firstIndex;
    try{
        firstIndex = getVertexIndex(start);
    }
    catch(const char* e){
        throw "start vertex not found";
    }
    
    int secondIndex;
    try{
        secondIndex = getVertexIndex(end);
    }
    catch(const char* e){
        throw "end vertex not found";
    }

    if(weights[firstIndex][secondIndex] == __INT_MAX__ && weights[secondIndex][firstIndex] == __INT_MAX__){
        throw "edge not found";
    }
    
    return weights[firstIndex][secondIndex];
}
    
template<class LabelType>
void AMGraph<LabelType>::depthFirstTraversal(LabelType start, void visit(LabelType&)){
    bool seen[numItems] = {false}, stop;
    stack<int> forLater;
    int vertex, index;
    
    try{
        vertex = getVertexIndex(start);
    }
    catch(const char* e){
        throw "invalid starting vertex";
    }

    forLater.push(vertex);
    seen[vertex] = true;
    visit(items[vertex]);

    while(!forLater.empty()){
        vertex = forLater.top();

        stop = false;
        for(index = 0; index < numItems && !stop; index++){
            if(weights[vertex][index] != __INT_MAX__ && !seen[index]){
                stop = true;
            }
        }

        if(stop){
            index--;
            forLater.push(index);
            seen[index] = true;
            visit(items[index]);
        }
        else{
            forLater.pop();
        }
    }
}
    
template<class LabelType>
void AMGraph<LabelType>::breadthFirstTraversal(LabelType start, void visit(LabelType&)){
    bool seen[numItems] = {false};
    queue<int> forLater;
    int vertex;
    
    try{
        vertex = getVertexIndex(start);
    }
    catch(const char* e){
        throw "invalid starting vertex";
    }

    forLater.push(vertex);
    seen[vertex] = true;
    visit(items[vertex]);

    while(!forLater.empty()){
        vertex = forLater.front();

        for(int index = 0; index < numItems; index++){
            if(weights[vertex][index] != __INT_MAX__ && !seen[index]){
                forLater.push(index);
                seen[index] = true;
                visit(items[index]);
            }
        }
        forLater.pop();
    }
}
